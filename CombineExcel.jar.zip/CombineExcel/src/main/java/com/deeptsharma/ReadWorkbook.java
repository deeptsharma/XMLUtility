package com.deeptsharma;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import org.apache.poi.ss.usermodel.Workbook;

import com.deeptsharma.utility.ApplicationConstants;
import com.deeptsharma.utility.ApplicationUtility;
import com.deeptsharma.vo.SheetDetails;

public class ReadWorkbook {
	public static void readWorkbook(Workbook workbook, SheetDetails mainSheet, List<SheetDetails> sheetDetailList, String outputFileName, String primaryKeyColHeader) {
		StringJoiner header=new StringJoiner(ApplicationConstants.VALUE_SEPARATOR);
		header.add(primaryKeyColHeader);
		
		Map<String,List<String>> rows=ReadSheet.readMainSheet(workbook,mainSheet,header);
 
		Map<String,List<String>> othersSheets;
		for(SheetDetails sheetDetails:sheetDetailList) {
			othersSheets=ReadSheet.readMainSheet(workbook,sheetDetails,header);
			combineMap(rows,othersSheets);
		}
		
		ApplicationUtility.createExcelFile(outputFileName, header.toString(), rows);
 	}

	private static  void combineMap(Map<String, List<String>> rows, Map<String, List<String>> othersSheets) {

		for(Map.Entry<String, List<String>> entry:rows.entrySet()) {
			
			List<String> rowsList=entry.getValue();
			List<String> othersSheetsList=othersSheets.get(entry.getKey());
			
			if(rowsList!=null && othersSheetsList!=null) {
				List<String> result=new ArrayList<>();
			
				for(String outer:rowsList) {
					for(String inner:othersSheetsList) {
						result.add(outer+ApplicationConstants.VALUE_SEPARATOR+inner);
					}
				}
				rows.put(entry.getKey(), result);
			}
		}
	}
}
