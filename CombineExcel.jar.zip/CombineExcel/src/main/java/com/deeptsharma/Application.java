package com.deeptsharma;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.deeptsharma.vo.SheetDetails;

public class Application {
	private static final String INPUT_FILE_NAME="D:\\Java\\eclipse workspace\\CombineExcel\\MyExcel.xlsx";
	private static final String OUTPUT_FILE_NAME="D:\\Java\\eclipse workspace\\CombineExcel\\MyFinalExcel.xlsx";
	private static final String PRIMARY_KEY_COL_HEADER="PK";
	
	
	public static void main(String[] args)  {
		try (Workbook workbook= WorkbookFactory.create(Files.newInputStream(Paths.get(INPUT_FILE_NAME)))){
			ReadWorkbook.readWorkbook(workbook,getMainSheetDetails(),getSheetDetails(),OUTPUT_FILE_NAME,PRIMARY_KEY_COL_HEADER);
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
	}
	static SheetDetails getMainSheetDetails() {
		SheetDetails sheetDetails=new SheetDetails();
		sheetDetails.setSheetName("Employee");
		sheetDetails.setHeaderRowNumber(0);
		sheetDetails.setDataStartRowNumber(1);
		sheetDetails.setPrimaryKeyPosition(0);
		return sheetDetails;
	}
	static List<SheetDetails> getSheetDetails(){
		List<SheetDetails> details=new ArrayList<>();
		SheetDetails details2=new SheetDetails();
		details2.setSheetName("ContactDetails");
		details2.setHeaderRowNumber(0);
		details2.setDataStartRowNumber(1);
		details2.setPrimaryKeyPosition(0);
		details.add(details2);
		
		details2=new SheetDetails();
		details2.setSheetName("Address");
		details2.setHeaderRowNumber(0);
		details2.setDataStartRowNumber(1);
		details2.setPrimaryKeyPosition(0);
		details.add(details2);
		
		return details;
	}
}
