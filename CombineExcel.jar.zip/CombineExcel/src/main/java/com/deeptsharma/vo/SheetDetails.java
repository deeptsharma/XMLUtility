package com.deeptsharma.vo;

public class SheetDetails {
	private String sheetName;
	
	/**
	 * primary key column no from left starting from 0
	 */
	private int primaryKeyPosition;
	
	private int headerRowNumber;
	private int dataStartRowNumber;
	
	public String getSheetName() {
		return this.sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	public int getPrimaryKeyPosition() {
		return this.primaryKeyPosition;
	}
	public void setPrimaryKeyPosition(int primaryKeyPosition) {
		this.primaryKeyPosition = primaryKeyPosition;
	}
	public int getHeaderRowNumber() {
		return this.headerRowNumber;
	}
	public void setHeaderRowNumber(int headerRowNumber) {
		this.headerRowNumber = headerRowNumber;
	}
	public int getDataStartRowNumber() {
		return this.dataStartRowNumber;
	}
	public void setDataStartRowNumber(int dataStartRowNumber) {
		this.dataStartRowNumber = dataStartRowNumber;
	}
	@Override
	public String toString() {
		return "SheetDetails [sheetName=" + this.sheetName + ", primaryKeyPosition=" + this.primaryKeyPosition
				+ ", headerRowNumber=" + this.headerRowNumber + ", dataStartRowNumber=" + this.dataStartRowNumber + "]";
	}
}