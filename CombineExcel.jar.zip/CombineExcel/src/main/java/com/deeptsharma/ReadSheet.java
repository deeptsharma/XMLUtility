package com.deeptsharma;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import com.deeptsharma.utility.ApplicationConstants;
import com.deeptsharma.vo.SheetDetails;

public class ReadSheet {
	public static Map<String, List<String>> readMainSheet(Workbook workbook, SheetDetails mainSheet,StringJoiner header) {
		Map<String, List<String>> map=new HashMap<>();
		
		Sheet sheet=workbook.getSheet(mainSheet.getSheetName());
		getHeader(sheet, mainSheet.getHeaderRowNumber(),header,mainSheet.getPrimaryKeyPosition());
		
		String key=null;
		for(Row row:sheet) {
			if(row.getRowNum()>=mainSheet.getDataStartRowNumber()) {
				StringJoiner joiner=new StringJoiner(ApplicationConstants.VALUE_SEPARATOR);
				for(Cell cell:row) {
					cell.setCellType(CellType.STRING);

					if(cell.getColumnIndex()==mainSheet.getPrimaryKeyPosition()) {
						key=cell.getStringCellValue();
					}
					else {
						joiner.add(cell.getStringCellValue());						
					}
				}
				addRow(map,key,joiner.toString());
			}
		}
		return map;
	}
	
	private static void addRow(Map<String, List<String>> map, String key, String joiner) {
		if(map.containsKey(key)) {
			map.get(key).add(joiner);
		}
		else {
			List<String> row=new ArrayList<>();
			row.add(joiner);
			map.put(key, row);
		}
	}
	private static String getHeader(Sheet sheet, int headerRowNumber,StringJoiner header, int primaryKeyColumnIndex) {
		for(Cell cell:sheet.getRow(headerRowNumber)) {
			if(cell.getColumnIndex()!=primaryKeyColumnIndex) {
				cell.setCellType(CellType.STRING);
				header.add(cell.getStringCellValue());
			}
		}		
		return header.toString();
	}
}
