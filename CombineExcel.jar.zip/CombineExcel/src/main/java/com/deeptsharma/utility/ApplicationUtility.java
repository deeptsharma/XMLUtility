package com.deeptsharma.utility;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ApplicationUtility {
	public static void createExcelFile(String fileName,String headerString, Map<String,List<String>> rows) {
		
		try (XSSFWorkbook workbook = new XSSFWorkbook()){
	        XSSFSheet sheet = workbook.createSheet("Sheet 1");
	        int rowNum=0;
	        int cellNo=0;
	        Cell cell;
	        Row row=sheet.createRow(rowNum++);
	        for(String header:headerString.split(ApplicationConstants.SPLIT__SEPARATOR)) {
	        	cell=row.createCell(cellNo++);
	        	cell.setCellValue(header);
	        }
	        
	        for(Map.Entry<String,List<String>> entry:rows.entrySet()) {
	        	for(String line:entry.getValue()) {
	        		row=sheet.createRow(rowNum++);

	        		cell=row.createCell(0);
    	        	cell.setCellValue(entry.getKey());
	        		cellNo=1;    	        	
	        		for(String header:line.split(ApplicationConstants.SPLIT__SEPARATOR)) {
	    	        	cell=row.createCell(cellNo++);
	    	        	cell.setCellValue(header);
	    	        }
	        	}
	        }
	        
	        try (OutputStream out=Files.newOutputStream(Paths.get(fileName))){
	        	workbook.write(out);
	        } catch (IOException e) {
				e.printStackTrace();
			}
	        
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
