package com.deeptsharma.utility;

public final class ApplicationConstants {
	public static final String VALUE_SEPARATOR="$"; 
	public static final String SPLIT__SEPARATOR="[$]"; 
}
